
int main(){
    int i = 0;
    int a[3];
    a[0] = 1;
    return 1;
}