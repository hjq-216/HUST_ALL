package homework.ch11_13.p3;

import java.util.Objects;

public class Faculty extends Person implements Cloneable{
    private int facultyId;
    private String title;
    private String email;

    public Faculty() {
        super();
    }

    public Faculty(String name, int age, int facultyId, String title, String email) {
        super(name, age);
        this.facultyId = facultyId;
        this.title = title;
        this.email = email;
    }

    public int getFacultyId() {
        return facultyId;
    }

    public void setFacultyId(int facultyId) {
        this.facultyId = facultyId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString(){
        return "Teacher Info: " + super.toString()
                + "facultyId: " + facultyId + "， "
                + "title: " + title + "， "
                + "email: " + email;
    }

    @Override
    public boolean equals(Object obj){
        if(this == obj){
            return true;//地址相等
        }

        if(obj == null){
            return false;//非空性：对于任意非空引用x，x.equals(null)应该返回false。
        }

        if(obj instanceof Faculty){
            Person other1 = (Person) obj;
            Faculty other2 = (Faculty) obj;
            //需要比较的字段相等，则这两个对象相等
            return super.equals(obj) && facultyId == other2.facultyId
                    && Objects.equals(title,other2.title) && Objects.equals(email, other2.email);
        }

        return false;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        Faculty faculty = (Faculty) super.clone();
        faculty.facultyId = facultyId;
        faculty.title = new String(title);
        faculty.email = new String(email);
        return faculty;
    }
}
