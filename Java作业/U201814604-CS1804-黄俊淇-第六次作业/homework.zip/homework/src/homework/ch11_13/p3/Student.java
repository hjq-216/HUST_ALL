package homework.ch11_13.p3;

import java.util.Objects;

public class Student extends Person implements Cloneable{
    private int studentId;
    private String department;
    private String classNo;

    public Student() { }

    public Student(String name, int age, int studentId, String department, String classNo) {
        super(name, age);
        this.studentId = studentId;
        this.department = department;
        this.classNo = classNo;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getClassNo() {
        return classNo;
    }

    public void setClassNo(String classNo) {
        this.classNo = classNo;
    }

    @Override
    public String toString() {
        return super.toString()
                + "studentId: " + studentId + "， "
                + "department: " + department + "， "
                + "classNo: " + classNo;
    }

    @Override
    public boolean equals(Object obj){
        if(this == obj){
            return true;//地址相等
        }

        if(obj == null){
            return false;//非空性：对于任意非空引用x，x.equals(null)应该返回false。
        }

        if(obj instanceof Student){
            Person other1 = (Person) obj;
            Student other2 = (Student) obj;
            //需要比较的字段相等，则这两个对象相等
            return super.equals(obj) && studentId == other2.studentId
                    && Objects.equals(department,other2.department) && Objects.equals(classNo, other2.classNo);
        }

        return false;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        Student student = (Student) super.clone();
        student.studentId = studentId;
        student.department = new String(department);
        student.classNo = new String(classNo);
        return student;
    }
}
