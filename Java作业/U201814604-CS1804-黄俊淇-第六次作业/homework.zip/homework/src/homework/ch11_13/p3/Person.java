package homework.ch11_13.p3;

import java.util.Objects;

public class Person implements Cloneable{
    private String name;
    private int age;

    public Person() { }

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString(){
        return "name: " + name + "， " + "age: " + age + "， ";
    }

    @Override
    public boolean equals(Object obj){
        if(this == obj){
            return true;//地址相等
        }

        if(obj == null){
            return false;//非空性：对于任意非空引用x，x.equals(null)应该返回false。
        }

        if(obj instanceof Person){
            Person other = (Person) obj;
            //需要比较的字段相等，则这两个对象相等
            return Objects.equals(name, other.name) && age == other.age;
        }

        return false;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        Person person = (Person) super.clone();
        person.age = age;
        person.name = new String(name);
        return person;
    }
}
