package homework.ch11_13.p3;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

public class Course implements Cloneable{
    private String courseName;
    private List<Person> students;
    private Person teacher;

    public Course(String courseName, Person teacher) {
        this.courseName = courseName;
        this.teacher = teacher;
        students = new ArrayList<>();
    }

    public void register(Person person){
        for (Person student : students){
            if(student.getName().equals(person.getName()))
                return;
        }

        students.add(person);
    }

    public String getCourseName() {
        return courseName;
    }

    public List<Person> getStudents() {
        return students;
    }

    public Person getTeacher() {
        return teacher;
    }

    public void unregister(Person person){
        students.removeIf(student -> student.getName().equals(person.getName()));
    }

    public int getNumberOfStudent(){
        return students.size();
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        Course course = (Course) super.clone();
        course.courseName = new String(courseName);
        course.teacher = (Person) teacher.clone();
        course.students = new ArrayList<>();
        for(Person student:students){
            Person newStudent = (Person) student.clone();
            course.students.add(newStudent);
        }
        return course;
    }

    @Override
    public String toString() {
        String s = "Course Name: " + courseName + "\n";
        s += teacher.toString() + "\n";
        s += "Student List: \n";
        for (Person person : students){
            s += "\t"+person.toString() + "\n";
        }
        s += "Totally: " +students.size() + " students.";

        return s;
    }

    @Override
    public boolean equals(Object obj){
        if(this == obj){
            return true;//地址相等
        }

        if(obj == null){
            return false;//非空性：对于任意非空引用x，x.equals(null)应该返回false。
        }

        if(obj instanceof Course){
            Course course = (Course) obj;
            return course.courseName.equals(courseName) && teacher.equals(course.teacher)
                    && students.size() == course.students.size() && students.containsAll(course.students);
        }

        return false;
    }
}
