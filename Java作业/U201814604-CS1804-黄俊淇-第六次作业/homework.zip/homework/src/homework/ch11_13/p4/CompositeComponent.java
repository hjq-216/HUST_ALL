package homework.ch11_13.p4;

public class CompositeComponent extends Component{
    private ComponentList childs;

    public CompositeComponent() { }

    public CompositeComponent(int id, String name, double price) {
        super(id, name, price);
        childs = new ComponentList();
    }

    @Override
    public void add(Component component) {
        childs.add(component);
    }

    @Override
    public void remove(Component component) {
        if(childs.size()>0){
            Iterator it= childs;
            while(it.hasNext()){
                Component c = it.next();
                if(c.getId()==component.getId()){
                    childs.remove(c);
                }
            }
        }
    }

    @Override
    public double calcPrice() {
        double price=0;
        if(childs.size()>0){
            for (Component c:childs){
                price += c.getPrice();
            }
        }
        setPrice(price);
        return price;
    }

    @Override
    public Iterator iterator() {
        return new CompositeIterator(childs);
    }

    @Override
    public String toString() {
        String indent = "";
        StringBuilder buf  = new StringBuilder();
        buf.append("id: ").append(getId()).append(", name: ").
                append(getName()).append(", price: ").append(getPrice()).append("\n");
        if (childs.size() > 0){
            buf.append(indent).append("sub-components of ").append(getName()).append(":").append("\n");
            for (Component c : childs){
                buf.append(c.toString()).append("\n");
            }
        }
        return buf.toString();
    }
}
