package homework.ch11_13.p4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ComponentFactory {
    public ComponentFactory() {
    }

    public static Component create() {
        int id = 0;

        String aName1 = "aaa1";
        String aName2 = "aaa2";
        String aName3 = "aaa3";
        String aName4 = "aaa4";
        double aPrice1 = 5.0D;
        double aPrice2 = 10.0D;
        double aPrice3 = 15.0D;
        double aPrice4 = 25.0D;

        Component a1 = new AtomicComponent(id++, aName1, aPrice1);
        Component a2 = new AtomicComponent(id++, aName2, aPrice2);
        Component a3 = new AtomicComponent(id++, aName3, aPrice3);
        Component a4 = new AtomicComponent(id++, aName4, aPrice4);

        String cName1 = "ccc1";
        String cName2 = "ccc2";
        String cName3 = "ccc3";

        Component c1 = new CompositeComponent(id++, cName1, 10.0D);
        Component c2 = new CompositeComponent(id++, cName2, 10.0D);

        String tName = "root";

        Component root = new CompositeComponent(id++, tName, 100.0D);

        c1.add(a1);
        c1.add(a2);
        c1.add(c2);
        c2.add(a3);
        c2.add(a4);

        System.out.println(root.getPrice());
        System.out.println(root.calcPrice());
        System.out.println(c1.getPrice());
        System.out.println(c1.calcPrice());
        root.add(c1);

        List childList = Arrays.asList( c1, a1, a2, c2, a3, a4);
        List list = new ArrayList();
        Iterator it = root.iterator();
        while (it.hasNext()) {

            list.add(it.next());
        }
        System.out.println(list.size() );
        System.out.println( list.containsAll(childList));

        c2.remove(a3);
        c2.remove(a4);
        return a1;

    }
}
