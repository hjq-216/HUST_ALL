package homework.ch11_13.p4;


import java.util.Objects;

public abstract class Component {
    private int id;
    private String name;
    protected double price;

    public Component() { }

    public Component(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        this.price = this.calcPrice();
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public abstract void add(Component component);

    public abstract double calcPrice();

    public abstract Iterator iterator();

    public abstract void remove(Component component);

    @Override
    public boolean equals(Object obj){
        if(this == obj){
            return true;//地址相等
        }

        if(obj == null){
            return false;//非空性：对于任意非空引用x，x.equals(null)应该返回false。
        }

        if(obj instanceof Component){
            Component other = (Component) obj;
            //需要比较的字段相等，则这两个对象相等
            return id == other.id && Objects.equals(name, other.name) && price == other.price;
        }

        return false;

    }

    @Override
    public String toString(){
        return "id: " + id + ", " + "name: " + name + ", " + "price: " + price;
     }
}
