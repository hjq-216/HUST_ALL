package homework.ch11_13.p4;

public interface Iterator {
    boolean hasNext();
    Component next();
}
