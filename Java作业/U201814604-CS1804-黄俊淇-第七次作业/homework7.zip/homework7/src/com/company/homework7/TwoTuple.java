package com.company.homework7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TwoTuple <T1 extends Comparable<T1>,T2 extends Comparable<T2>> implements Comparable<TwoTuple<T1,T2>>{
    private T1 first;
    private T2 second;

    public TwoTuple(T1 first, T2 second) {
        this.first = first;
        this.second = second;
    }

    public T1 getFist() {
        return first;
    }

    public void setFist(T1 fist) {
        this.first = fist;
    }

    public T2 getSecond() {
        return second;
    }

    public void setSecond(T2 second) {
        this.second = second;
    }

    @Override
    public boolean equals(Object obj){
        if (this == obj) {
            return true;
        }

        if (obj instanceof TwoTuple) {
            TwoTuple <T1,T2> newObj = (TwoTuple<T1, T2>) obj;
            return newObj.first.equals(first) && newObj.second.equals(second);
        }
        return false;
    }

    @Override
    public String toString() {
        return "(" + first + "," + second + ")";
    }

    @Override
    public int compareTo(TwoTuple<T1, T2> o) {
        if (o.first.compareTo(first) != 0){
            return first.compareTo(o.first);
        }
        if (o.second.compareTo(second) != 0){
            return second.compareTo(o.second);
        }

        return 0;
    }

    public static void main(String[] args){
        TwoTuple<Integer, String> twoTuple1 = new TwoTuple<>(1, "ccc");
        TwoTuple<Integer, String> twoTuple2 = new TwoTuple<>(1, "bbb");
        TwoTuple<Integer, String> twoTuple3 = new TwoTuple<>(1, "aaa");
        TwoTuple<Integer, String> twoTuple4 = new TwoTuple<>(2, "ccc");
        TwoTuple<Integer, String> twoTuple5 = new TwoTuple<>(2, "bbb");
        TwoTuple<Integer, String> twoTuple6 = new TwoTuple<>(2, "aaa");
        List<TwoTuple<Integer, String >> list = new ArrayList<>();
        list.add(twoTuple1);
        list.add(twoTuple2);
        list.add(twoTuple3);
        list.add(twoTuple4);
        list.add(twoTuple5);
        list.add(twoTuple6);

        TwoTuple<Integer,String> twoTuple10 = new TwoTuple<>(1,"ccc");
        System.out.println(twoTuple1.equals(twoTuple10));
        if (!list.contains(twoTuple10)){
            list.add(twoTuple10);
        }

        Collections.sort(list);
        for (TwoTuple<Integer, String> t:list){
            System.out.println(t);
        }

        TwoTuple<TwoTuple<Integer,String>, TwoTuple<Integer,String>> tt1 =
                new TwoTuple<>(new TwoTuple<>(1,"aaa"), new TwoTuple<>(1,"bbb"));
        TwoTuple<TwoTuple<Integer,String>, TwoTuple<Integer,String>> tt2 =
                new TwoTuple<>(new TwoTuple<>(1,"aaa"), new TwoTuple<>(2,"bbb"));

        System.out.println(tt1.compareTo(tt2));
        System.out.println(tt1);
    }
}
