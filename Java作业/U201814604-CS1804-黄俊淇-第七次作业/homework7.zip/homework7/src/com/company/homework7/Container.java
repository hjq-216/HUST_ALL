package com.company.homework7;

import java.lang.reflect.Array;

public class Container<T> {
    private T[] elements;
    private int elementsCount = 0;
    private int size = 0;

    public Container(Class<T> clazz,int size){

        elements = (T[]) Array.newInstance(clazz, size);
        this.size = size;
    }

    public boolean add(T e){
        if (elementsCount < size){
            elements[elementsCount++] = e;
            return true;
        }
        else {
            return false;
        }
    }

    public Iterator<T> iterator(){
        return new ArrayIterator<T>(elements);
    }
}
