package com.company.homework7;

public interface Iterator <T> {
    boolean hasNext();
    T next();
}
