#include <stdio.h>
#include <stdlib.h>
#pragma inline

char a[20] = { "huangjunqi0" };
char b[20];
char c[10] = { "123450" };
char d[10];

	char name1[10]={ "pen0" };
	int discount1 = 10;
	int cprice1 = 35;
	int sprice1 = 56;
	int cnumber1 = 70;
	int snumber1 = 25;
	int recommand1 = 0;

	char name2[10] = { "book0" };
	int discount2 = 9;
	int cprice2 = 12;
	int sprice2 = 30;
	int cnumber2 = 25;
	int snumber2 = 5;
	int recommand2 = 0;

	char name3[10] = { "bag0" };
	int discount3 = 9;
	int cprice3 = 10;
	int sprice3 = 20;
	int cnumber3 = 1000;
	int snumber3 = 0;
	int recommand3 = 0;
	char item[10];
	int recommand = 0;
int flag1 = 1;
int flag = 0;
int AUTH = 0;
int GOOD = 0;
int data = 0;
void printMENU(void) {
	printf("1 sign in\n");
	printf("2 serch goods\n");
	printf("3 order\n");
	printf("4 calculate\n");
	printf("5 sort\n");
	printf("6 revise\n");
	printf("7 change experiment\n");
	printf("8 show\n");
	printf("9 quit\n");
}
void FUNC1D(char a, char b) {
	__asm {
		push ax
		push bx
		mov ax,a
		mov bx,b
		sub ax,bx
		mov flag1,ax
	    pop bx
		pop ax
	}
}
void FUNC1(void) {
	int i = 0;
	int count = 0;
	int count1 = 0;
	i = 0;
	count = 0;
	count1 = 0;
	printf("please enter your name\n");
	scanf("%s", b);
	printf("%c", b[10]);
	while (a[i] != '0') {
		asm push ds
			FUNC1D(a[i], b[i]);
		asm pop ds
			if (flag1 == 0) count++;

		i++;
	}
	printf("please enter your password\n");
	scanf("%s", d);
	i = 0;

	count1 = 0;
	while (c[i] != '0') {
		asm push ds
			FUNC1D(c[i], d[i]);
		asm pop ds
			if (flag1 == 0) count1++;

		i++;
	}

	if ((count == 10)) {
		if (count1 == 5) {
			printf("AUTO SUCCESS\n");
			AUTH = 1;
		}
		else printf("access denied\n");
	}
	else printf("access denied\n");
}
void FUNC2(void) {
	int count1 = 0;
	int i = 0;
	printf("please enter a name to seach\n");
	scanf("%s", item);
	 
	while (name1[i] != '0') {
		FUNC1D(name1[i], item[i]);
		if (flag1 == 0) count1++;
		i++;
	}
	if (count1 == 3) {
		GOOD = 1;
		printf("%s\n", item);
		printf("%d\n", discount1);
		printf("%d\n", cprice1);
		printf("%d\n", sprice1);
		printf("%d\n", cnumber1);
		printf("%d\n", snumber1);
		printf("%d\n", recommand1);
		return;
	}
	else {
		 count1 = 0;
		 i = 0;
		while (name2[i] != '0') {
			FUNC1D(name2[i], item[i]);
			if (flag1 == 0) count1++;
			i++;
		}
		if (count1 == 4) {
			GOOD = 2;
			printf("%s\n", item);
			printf("%d\n", discount2);
			printf("%d\n", cprice2);
			printf("%d\n", sprice2);
			printf("%d\n", cnumber2);
			printf("%d\n", snumber2);
			printf("%d\n", recommand2);
			return;
		}
		else {
			 count1 = 0;
			 i = 0;
			while (name3[i] != '0') {
				FUNC1D(name3[i], item[i]);
				if (flag1 == 0) count1++;
				i++;
			}
			if (count1 == 3) {
				GOOD = 3;
				printf("%s\n", item);
				printf("%d\n", discount3);
				printf("%d\n", cprice3);
				printf("%d\n", sprice3);
				printf("%d\n", cnumber3);
				printf("%d\n", snumber3);
				printf("%d\n", recommand3);
				return;
			}
			else {
				printf("access denied\n");
				return;
			}
		}
	}
}
void calculate(int a, int b, int c, int d,int e) {
	__asm {
		push ax
		push bx
		push cx
		push dx
		mov ax,a
		
		mov bx,10
		mov cx,c
		mul cx
		div bx
		
		mov cx,ax
		
		mov ax,b
		mov bx,128
		mul bx
		div cx
		
		mov cx,ax
		
		mov ax,e
		mov bx, 64
		mul bx
		mov bx,d
		div bx
		
		add ax,cx
		mov recommand,ax

		pop dx
		pop cx
		pop bx
		pop ax
	}
}

void FUCN3(void) {
	if (GOOD == 1) {
		snumber1++;
		calculate(discount1, cprice1, sprice1, cnumber1, snumber1);
		recommand1 = recommand;
		printf("%d\n", recommand1);
		
		return;
	}
	else if (GOOD == 2) {
		snumber2++;
		calculate(discount2, cprice2, sprice2, cnumber2, snumber2);
		recommand2 = recommand;
		printf("%d\n", recommand2);
		return;
	}
	else if (GOOD == 3) {
		snumber3++;
		calculate(discount3, cprice3, sprice3, cnumber3, snumber3);
		recommand3 = recommand;
		printf("%d\n", recommand3);
		return;
	}
	else {
		printf("access denied\n");
		return;
	}
}
void FUNC4(void) {
	calculate(discount1, cprice1, sprice1, cnumber1, snumber1);
	recommand1 = recommand;
	printf("%d\n", recommand1);
	calculate(discount2, cprice2, sprice2, cnumber2, snumber2);
	recommand2 = recommand;
	printf("%d\n", recommand2);
	calculate(discount3, cprice3, sprice3, cnumber3, snumber3);
	recommand3 = recommand;
	printf("%d\n", recommand3);
}
void FUNC6(void) {
	int temp;
	if (AUTH == 0) {
		printf("access denied\n");
		return;
	}
	if (GOOD == 1) {
		printf("please enter discount\n");
			scanf("%d", &temp);
		discount1 = temp;
		printf("please enter cprice\n");
			scanf("%d", &temp);
		cprice1= temp;
		printf("please enter sprice\n");
			scanf("%d", &temp);
		sprice1 = temp;
		printf("please enter cnumber\n");
			scanf("%d", &temp);
		cnumber1 = temp;
		return;
	}
	else if (GOOD == 2) {
		printf("please enter discount\n");
			scanf("%d", &temp);
		discount2 = temp;
		printf("please enter cprice\n");
			scanf("%d", &temp);
		cprice2 = temp;
		printf("please enter sprice\n");
			scanf("%d", &temp);
		sprice2 = temp;
		printf("please enter cnumber\n");
			scanf("%d", &temp);
		cnumber2 = temp;
		return;
	}
	else if (GOOD == 3) {
		printf("please enter discount\n");
			scanf("%d", &temp);
		discount3 = temp;
		printf("please enter cprice\n");
			scanf("%d", &temp);
		cprice3 = temp;
		printf("please enter sprice\n");
			scanf("%d", &temp);
		sprice3 = temp;
		printf("please enter cnumber\n");
			scanf("%d", &temp);
		cnumber3 = temp;
		return;
	}
	else {
		printf("access denied\n");
		return;
	}
}
void FUNC8(void) {
	__asm {
		push ax
		mov ax,ds
		mov data,ax
		pop ax
	}
}
int main(void) {
	int choice=0;
	
	
	while (choice != 9) {
		if (AUTH == 1) printf("huangjunqi\n");
		else printf("customer\n");
		if (GOOD == 1) printf("pen\n");
		else if (GOOD == 2) printf("book\n");
		else if (GOOD == 3) printf("bag\n");
		else printf("\n");
		printMENU();
		printf("please enter a number to choose function\n");
		scanf("%d", &choice);
		
		switch (choice)
		{
		case 1:
			FUNC1();
			break;
		case 2:
			FUNC2();
			break;
		case 3:
			FUCN3();
			break;
		case 4:
			FUNC4();
			break;
		case 6:
			FUNC6();
			break;
		case 8:
			FUNC8();
			printf("%d\n", data);
			break;
		default:
			break;
		}
	}
	return 0;
}
