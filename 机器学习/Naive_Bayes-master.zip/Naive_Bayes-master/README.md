# Naive_Bayes
朴素贝叶斯算法实战
email邮件数据集，SogouC新闻数据集
Email_NB.py垃圾邮件过滤实现（Python3实现）
Naive_Bay.py 朴素贝叶斯算法实现（Python3实现）
News_NB.py新闻分类实现（Sklearn实现）
